﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C969_Scheduler
{
    public class Country
    {
        public int countryId { get; set; }
        public string country { get; set; }
    }
}
